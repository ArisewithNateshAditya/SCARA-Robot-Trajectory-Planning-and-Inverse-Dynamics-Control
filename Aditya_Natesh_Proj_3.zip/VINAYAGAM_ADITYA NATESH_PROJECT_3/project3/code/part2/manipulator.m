function output=manipulator(input)
