syms centreofmassoflink1 centreofmassoflink2
syms theta_1_dot theta_2_dot d_3_dot theta_4_dot
syms theta_1 theta_2 d_3 theta_4
syms ('C_temp',[4 4 4]);
syms ('C_matrix',[4 4]);

%lm - link mass
%li - moment of inertia of link
%mi - moment of inertia of motor
%a-links

a1=0.5;
a2=0.5;
lm1 = 25;
lm2 = 25;
lm3 = 10;
lm4 = 5;
li1=5;
li2=5;
li3=0;
li4=1;
mi1=0.0001;
mi2=0.0001;
mi3=0.01;
mi4=0.005;
F1=0.0001;
F2=0.0001;
F3=0.01;
F4=0.005;
gear_ratio_1=1;
gear_ratio_2=1;
gear_ratio_3=50;
gear_ratio_4=20;


%Position Jacobian matrix for motors and links
jacobian_p_m1 = [0 0 0 0;
                 0 0 0 0;
                 0 0 0 0;];

jacobian_p_m2 = [(-a1)*sin(theta_1) 0 0 0;
                 (a1)*cos(theta_1)  0 0 0;
                      0           0 0 0;];

jacobian_p_m3 = [-a1*sin(theta_1)-a2*sin(theta_1+theta_2) -a2*sin(theta_1+theta_2) 0 0;
                  a1*cos(theta_1)+a2*cos(theta_1+theta_2)  a2*cos(theta_1+theta_2) 0 0;
                                 0                               0            0 0;];

jacobian_p_m4 = jacobian_p_m3;

jacobian_p_l1 = [(-a1)*sin(theta_1) 0 0 0;
                  (a1)*cos(theta_1) 0 0 0;
                        0         0 0 0;];

jacobian_p_l2 = [-a1*sin(theta_1)-a2*sin(theta_1+theta_2) -a2*sin(theta_1+theta_2) 0 0;
                  a1*cos(theta_1)+a2*cos(theta_1+theta_2)  a2*cos(theta_1+theta_2) 0 0;
                                 0                               0            0 0;];

jacobian_p_l3 = [-a1*sin(theta_1)-a2*sin(theta_1+theta_2) -a2*sin(theta_1+theta_2) 0 0;
                  a1*cos(theta_1)+a2*cos(theta_1+theta_2)  a1*cos(theta_1+theta_2) 0 0;
                                0                                   0        -1 0;];

jacobian_p_l4 = jacobian_p_l3;

%Orientation Jacobian matrix for motors and links

jacobian_o_m1 = [0   0 0 0;
                 0   0 0 0;
                 gear_ratio_1 0 0 0;];

jacobian_o_m2 = [0 0   0 0;
                 0 0   0 0;
                 1 gear_ratio_2 0 0;];

jacobian_o_m3 = [0 0 0 0;
                 0 0 0 0;
                 1 1 -gear_ratio_3 0;];

jacobian_o_m4 = [0 0 0 0;
                 0 0 0 0;
                 1 1 0 gear_ratio_4;];

jacobian_o_l1 = [0 0 0 0;
                 0 0 0 0;
                 1 0 0 0;];

jacobian_o_l2 = [0 0 0 0;
                 0 0 0 0;
                 1 1 0 0;];

jacobian_o_l3 = [0 0 0 0;
                 0 0 0 0;
                 1 1 0 0;];

jacobian_o_l4 = [0 0 0 0;
                 0 0 0 0;
                 1 1 0 1;];

B1 = lm1*transpose(jacobian_p_l1)*(jacobian_p_l1) + transpose(jacobian_o_l1)*eye(3)*li1*transpose(eye(3))*(jacobian_o_l1) + transpose(jacobian_o_m1)*eye(3)*mi1*transpose(eye(3))*jacobian_p_m1;

B2 = lm2*transpose(jacobian_p_l2)*(jacobian_p_l2) + transpose(jacobian_o_l2)*eye(3)*li2*transpose(eye(3))*(jacobian_o_l2) + transpose(jacobian_o_m2)*eye(3)*mi2*transpose(eye(3))*jacobian_p_m2;

B3 = lm3*transpose(jacobian_p_l3)*(jacobian_p_l3) + transpose(jacobian_o_l3)*eye(3)*li3*transpose(eye(3))*(jacobian_o_l3)+ transpose(jacobian_o_m3)*eye(3)*mi3*transpose(eye(3))*jacobian_p_m3;

B4 = lm4*transpose(jacobian_p_l4)*(jacobian_p_l4) + transpose(jacobian_o_l4)*eye(3)*li4*transpose(eye(3))*(jacobian_o_l4) + transpose(jacobian_o_m4)*eye(3)*mi4*transpose(eye(3))*jacobian_p_m4;


B = simplify(B1+B2+B3+B4);


q=[theta_1;theta_2;d_3;theta_4];
q_dot=[theta_1_dot;theta_2_dot;d_3_dot;theta_2_dot];
for c =1:4
    for d = 1:4
         for e = 1:4
            C_temp(c,d,e)=0.5*(diff(B(c,d),q(e))+diff(B(c,e),q(d))-diff(B(d,e),q(c)));
        end
    end
end



for i=1:4
    for j=1:4
        
        C_matrix(i,j)=q_dot(1)*C_temp(i,j,1)+q_dot(2)*C_temp(i,j,2)+q_dot(3)*C_temp(i,j,3)+q_dot(4)*C_temp(i,j,4);
        
    end
end


C = simplify(C_matrix)

G=[0;0;-(lm3+lm4)*9.8;0];

F=diag([gear_ratio_1^2*F1 gear_ratio_2^2*F2 gear_ratio_3^2*F3 gear_ratio_4^2*F4]);
n= C_matrix*q_dot + F*q + G; 



 
