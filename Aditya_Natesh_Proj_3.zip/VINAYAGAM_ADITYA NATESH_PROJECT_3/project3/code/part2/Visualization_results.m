joint_pos = ans.Pos;
error_pos = ans.Jointposerror;
error_vel = ans.Jointvelocityerror;

tempq1 = joint_pos(1,:,:);
q1(:,1) = tempq1(1,1,:);
tempq2 = joint_pos(2,:,:);
q2(:,1) = tempq2(1,1,:);
tempq3 = joint_pos(3,:,:);
q3(:,1) = tempq3(1,1,:);
tempq4 = joint_pos(4,:,:);
q4(:,1) = tempq4(1,1,:);

figure(1)
subplot(5,1,1); plot(time, q1(:,1));title('Q1 Position')
subplot(5,1,2); plot(time, q2(:,1));title('Q2 Position')
subplot(5,1,3); plot(time, q3(:,1));title('Q3 Position')
subplot(5,1,4); plot(time, q4(:,1));title('Q4 Position')
subplot(5,1,5);

tempq1e = error_pos(1,:,:);
q1e(:,1) = tempq1e(1,1,:);
tempq2e = error_pos(2,:,:);
q2e(:,1) = tempq2e(1,1,:);
tempq3e = error_pos(3,:,:);
q3e(:,1) = tempq3e(1,1,:);
tempq4e = error_pos(4,:,:);
q4e(:,1) = tempq4e(1,1,:);

figure(2)
subplot(5,1,1); plot(time, q1e(:,1));title('Position Error in Q1')
subplot(5,1,2); plot(time, q2e(:,1));title('Position Error in Q2')
subplot(5,1,3); plot(time, q3e(:,1));title('Position Error in Q3')
subplot(5,1,4); plot(time, q4e(:,1));title('Position Error in Q4')
subplot(5,1,5);

tempq1ve = error_vel(1,:,:);
q1ve(:,1) = tempq1ve(1,1,:);
tempq2ve = error_vel(2,:,:);
q2ve(:,1) = tempq2ve(1,1,:);
tempq3ve = error_vel(3,:,:);
q3ve(:,1) = tempq3ve(1,1,:);
tempq4ve = error_vel(4,:,:);
q4ve(:,1) = tempq4ve(1,1,:);

figure(3)
subplot(5,1,1); plot(time, q1ve(:,1));title('Velocity Error in Q1')
subplot(5,1,2); plot(time, q2ve(:,1));title('Velocity Error in Q2')
subplot(5,1,3); plot(time, q3ve(:,1));title('Velocity Error in Q3')
subplot(5,1,4); plot(time, q4ve(:,1));title('Velocity Error in Q4')
subplot(5,1,5);