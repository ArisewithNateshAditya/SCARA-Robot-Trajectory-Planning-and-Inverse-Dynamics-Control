function jacobian_dot=j_diff(q,q_dot)

theta1=q(1);
theta2=q(2);
theta1_diff=q_dot(1);
theta2_diff=q_dot(2);

sigma1=(sin(theta1+theta2)*(theta1_diff+theta2_diff))/2;
sigma2=(cos(theta1+theta2)*(theta1_diff+theta2_diff))/2;

jacobian_dot=[-((cos(theta1*theta1_diff))/2)-sigma2 -sigma2 0 0;
    -((sin(theta1*theta1_diff))/2)-sigma1 -sigma1 0 0;
    0 0 0 0;
    0 0 0 0;];

jacobian_dot =jacobian_dot;

end