clear all
close all
clc
vrclear
vrclose

load('generated_kinematic_traj.mat');
control;
sim('control.mdl', time);
Visualization_results;
SCARA_VR_VISUALIZE(squeeze(joint_pos(:,1,:)), false);