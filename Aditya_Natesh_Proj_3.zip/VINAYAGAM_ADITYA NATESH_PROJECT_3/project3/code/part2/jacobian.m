function [output]=jacobian(input)
