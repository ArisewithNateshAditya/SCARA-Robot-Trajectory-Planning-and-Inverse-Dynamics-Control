function y = jacobian_inverse(q)

a0=0;
a1=0.5;
a2=0.5;
a3=0;
a4=0;
d0=1;
d1=0;
d2=0;
d4=0;
theta0=0;
theta1=q(1);
theta2=q(2);
d3=q(3);
theta4=q(4);
theta3=0;
alpha0=0;
alpha1=0;
alpha2=0;
alpha3=0;
alpha4=0;

T0=[1 0 0 0;
    0 1 0 0;
    0 0 1 1;
    0 0 0 1;];

T1=[cos(theta1) -sin(theta1)*cos(alpha1) sin(theta1)*sin(alpha1) a1*cos(theta1);
    sin(theta1) cos(theta1)*cos(alpha1) -cos(theta1)*sin(alpha1) a1*sin(theta1);
    0 sin(alpha1) cos(alpha1) d1;
    0 0 0 1;];

T2=[cos(theta2) -sin(theta2)*cos(alpha2) sin(theta2)*sin(alpha2) a2*cos(theta2);
    sin(theta2) cos(theta2)*cos(alpha2) -cos(theta2)*sin(alpha2) a2*sin(theta2);
    0 sin(alpha2) cos(alpha2) d2;
    0 0 0 1;];

T3=[cos(theta3) -sin(theta3)*cos(alpha3) sin(theta3)*sin(alpha3) a3*cos(theta3);
    sin(theta3) cos(theta3)*cos(alpha3) -cos(theta2)*sin(alpha3) a3*sin(theta3);
    0 sin(alpha3) cos(alpha3) -d3;
    0 0 0 1;];

T4=[cos(theta4) -sin(theta4)*cos(alpha4) sin(theta4)*sin(alpha4) a4*cos(theta4);
    sin(theta4) cos(theta4)*cos(alpha4) -cos(theta4)*sin(alpha4) a4*sin(theta4);
    0 sin(alpha4) cos(alpha4) d4;
    0 0 0 1;];

T00=T0;
T01=T0*T1;
T02=T01*T2;
T03=T02*T3;
T04=T03*T4;
Tend=T04;

Z0=[0;0;1];
P0=[0;0;0];
Z1=T01(1:3,3);
Z2=T02(1:3,3);
Z3=T03(1:3,3);
Z4=T04(1:3,3);

P1=T01(1:3,4);
P2=T02(1:3,4);
P3=T03(1:3,4);
P4=T04(1:3,4);
O=[0;0;0];

J1=[cross(Z0,(P4-P0));Z0];
J2=[cross(Z1,(P4-P1));Z1];
J3=[Z2;O];
J4=[cross(Z3,(P4-P3));Z3];

jac=[J1 J2 J3 J4];
jpart_1=jac(1:3,:);
jpart_2=jac(end,:);
jacnew=[jpart_1;jpart_2];

y=inv(jacnew);
% y=simplify(y);
end