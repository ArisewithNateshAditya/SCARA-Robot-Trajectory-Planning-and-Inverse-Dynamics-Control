%main code
clear all;
close all;
clc

%Way points of the robot in operational space
P0=[0 -0.80 0;];
P1=[0 -0.80 0.5;];
P2=[0.5 -0.6 0.5;];
P3=[0.8 0.0 0.5;];
P4=[0.8 0.0 0.0;];

%Initial Joint pos
q0 = [-0.927293431584587;-1.287005790420619;0.700000000000000;2.214299222005206];

%Sampling time
Ts=0.001;

%time stamp for path planning "T" 
T=[0 0.6 2 3.4 4];

%P0 to P1 Trajectory
Tdiff_0 = T(2) - T(1); 
ddqc_0 = (4*(P1-P0))/(Tdiff_0)^2;
ddqc_0 = ddqc_0+(ddqc_0/5);
Tc_0 = (Tdiff_0/2)-(0.5*sqrt((((Tdiff_0^2)*(ddqc_0))-4*((P1-P0)))/(ddqc_0)));
Position_0 = []; 
Velocity_0 = [];
Acceleration_0 = [];


for t = 0:Ts:Tdiff_0
    if (t<=Tc_0 && t>=0)
        Position_0(end+1,:) = P0 + ((1/2)*ddqc_0*(t^2)); 
        Velocity_0(end+1,:) = ddqc_0*t;
        Acceleration_0(end+1,:) = ddqc_0;
    elseif (t<= (Tdiff_0-Tc_0) && t>Tc_0)
        Position_0(end+1,:) = P0+(ddqc_0*Tc_0*(t-(Tc_0/2)));
        Velocity_0(end+1,:) = ddqc_0*Tc_0;
        Acceleration_0(end+1,:) = 0;
    elseif (t<=Tdiff_0 && t>(Tdiff_0-Tc_0))
        Position_0(end+1,:) = P1 - ((1/2)*ddqc_0*(Tdiff_0-t)^2);
        Velocity_0(end+1,:) = (ddqc_0*(Tdiff_0-t));
        Acceleration_0(end+1,:) = -ddqc_0;
    end
end

% P1 to P2 Trajectory
Tdiff_1 = T(3) - T(2);
ddqc_1 = (4*(P2-P1))/((Tdiff_1)^2);
ddqc_1 = ddqc_1+(ddqc_1/5);
Tc_1 = (Tdiff_1/2)-(0.5*sqrt((((Tdiff_1^2)*(ddqc_1))-(4)*(P2-P1))/(ddqc_1)));
Position_1 = []; 
Velocity_1 = [];
Acceleration_1 = [];


for t = 0:Ts:Tdiff_1
    if (t<=Tc_1 && t>=0)
        Position_1(end+1,:) = P1 + ((1/2)*ddqc_1*(t^2));
        Velocity_1(end+1,:) = ddqc_1*t;
        Acceleration_1(end+1,:) = ddqc_1;
    elseif (t<= (Tdiff_1-Tc_1) && t>Tc_1)
            Position_1(end+1,:) = P1+(ddqc_1*Tc_1*(t-(Tc_1/2)));
            Velocity_1(end+1,:) = ddqc_1*Tc_1;
            Acceleration_1(end+1,:) = 0;
    elseif (t<=Tdiff_1 && t>(Tdiff_1-Tc_1))
            Position_1(end+1,:) = P2 - ((1/2)*ddqc_1*(Tdiff_1-t)^2);
            Velocity_1(end+1,:) = (ddqc_1*(Tdiff_1-t));
            Acceleration_1(end+1,:) = -ddqc_1;
    end
end

% P2 to P3 Trajectory
Tdiff_2 = T(4) - T(3);
ddqc_2 = (4*(P3-P2))/((Tdiff_2)^2);
ddqc_2 = ddqc_2+(ddqc_2/5);
Tc_2 = (Tdiff_2/2)-(0.5*sqrt((((Tdiff_2^2)*(ddqc_2))-(4)*(P3-P2))/(ddqc_2)));
Position_2 = [];
Velocity_2 = [];
Acceleration_2 = [];


for t = 0:Ts:Tdiff_2
    if (t<=Tc_2 && t>=0)
        Position_2(end+1,:) = P2 + ((1/2)*ddqc_2*(t^2));
        Velocity_2(end+1,:) = ddqc_2*t;
        Acceleration_2(end+1,:) = ddqc_2;
    elseif (t<= (Tdiff_2-Tc_2) && t>Tc_2)
            Position_2(end+1,:) = P2+(ddqc_2*Tc_2*(t-(Tc_2/2)));
            Velocity_2(end+1,:) = ddqc_2*Tc_2;
            Acceleration_2(end+1,:) = 0;
    elseif (t<=Tdiff_2 && t>(Tdiff_2-Tc_2))
            Position_2(end+1,:) = P3 - ((1/2)*ddqc_2*(Tdiff_2-t)^2);
            Velocity_2(end+1,:) = (ddqc_2*(Tdiff_2-t));
            Acceleration_2(end+1,:) = -ddqc_2;
    end
end

%P3 to P4 Trajectory
Tdiff_3 = T(5) - T(4);
ddqc_3 = (4*(P4-P3))/((Tdiff_3)^2);
ddqc_3 = ddqc_3+(ddqc_3/5);
Tc_3 = (Tdiff_3/2)-(0.5*sqrt((((Tdiff_3^2)*(ddqc_3))-(4)*(P4-P3))/(ddqc_3)));
Position_3 = [];
Velocity_3 = [];
Acceleration_3 = [];


for t = 0:Ts:Tdiff_3
    if (t<=Tc_3 && t>=0)
        Position_3(end+1,:) = P3 + ((1/2)*ddqc_3*(t^2));
        Velocity_3(end+1,:) = ddqc_3*t;
        Acceleration_3(end+1,:) = ddqc_3;
    elseif (t<= (Tdiff_3-Tc_3) && t>Tc_3)
            Position_3(end+1,:) = P3+(ddqc_3*Tc_3*(t-(Tc_3/2)));
            Velocity_3(end+1,:) = ddqc_3*Tc_3;
            Acceleration_3(end+1,:) = 0;
    elseif (t<=Tdiff_3&& t>(Tdiff_3-Tc_3))
            Position_3(end+1,:) = P4 - ((1/2)*ddqc_3*(Tdiff_3-t)^2);
            Velocity_3(end+1,:) = (ddqc_3*(Tdiff_3-t));
            Acceleration_3(end+1,:) = -ddqc_3;
    end
end

%Positition Plot
Trajectory_Positions = [Position_0;Position_1;Position_2;Position_3]; 
Position_1_mat = Position_0(1:401,:);
Position_2_mat = Position_0(402:601,:);
Position_3_mat = Position_1(1:200,:);
Position_4_mat = Position_1(201:1200,:);
Position_5_mat = Position_1(1201:1400,:);
Position_6_mat = Position_2(1:200,:);
Position_7_mat = Position_2(201:1200,:);
Position_8_mat = Position_2(1201:1400,:);
Position_9_mat = Position_3(1:200,:);
Position_10_mat = Position_3(201:601,:);

% overallpos = [Position_0;Position_1;Position_2;Position_3;]
% plot3(Position_1_mat)
% The Position for the curves
Position_Curve_1= (Position_2_mat+Position_3_mat)-P1;
Position_Curve_2 = (Position_5_mat+Position_6_mat)-P2;
Position_Curve_3 = (Position_8_mat+Position_9_mat)-P3;
Position_curve_traj = [Position_1_mat;Position_Curve_1;Position_4_mat;Position_Curve_2;Position_7_mat;Position_Curve_3;Position_10_mat]; 

%Velocity plot
Velocity_1_mat=Velocity_0(1:401,:);
Velocity_2_mat=Velocity_0(402:601,:);
Velocity_3_mat=Velocity_1(1:200,:);
Velocity_4_mat=Velocity_1(201:1200,:);
Velocity_5_mat=Velocity_1(1201:1400,:);
Velocity_6_mat=Velocity_2(1:200,:);
Velocity_7_mat=Velocity_2(201:1200,:);
Velocity_8_mat=Velocity_2(1201:1400,:);
Velocity_9_mat=Velocity_3(1:200,:);
Velocity_10_mat=Velocity_3(201:601,:);

% The Velocity for the curves
Velocity_Curve_1 = (Velocity_2_mat+Velocity_3_mat);
Velocity_Curve_2 = (Velocity_5_mat+Velocity_6_mat);
Velocity_Curve_3 = (Velocity_8_mat+Velocity_9_mat);
Velocity_curve_traj = [Velocity_1_mat;Velocity_Curve_1;Velocity_4_mat;Velocity_Curve_2;Velocity_7_mat;Velocity_Curve_3;Velocity_10_mat]; 

%The Acceleration plot
Acceleration_1_mat = Acceleration_0(1:401,:);
Acceleration_2_mat = Acceleration_0(402:601,:);
Acceleration_3_mat = Acceleration_1(1:200,:);
Acceleration_4_mat = Acceleration_1(201:1200,:);
Acceleration_5_mat = Acceleration_1(1201:1400,:);
Acceleration_6_mat = Acceleration_2(1:200,:);
Acceleration_7_mat = Acceleration_2(201:1200,:);
Acceleration_8_mat = Acceleration_2(1201:1400,:);
Acceleration_9_mat = Acceleration_3(1:200,:);
Acceleration_10_mat = Acceleration_3(201:601,:);

% The Acceleration for the curves
Acceleration_Curve_1 = (Acceleration_2_mat+Acceleration_3_mat);
Acceleration_Curve_2 = (Acceleration_5_mat+Acceleration_6_mat);
Acceleration_Curve_3 = (Acceleration_8_mat+Acceleration_9_mat);
Acceleration_curve_traj = [Acceleration_1_mat;Acceleration_Curve_1;Acceleration_4_mat;Acceleration_Curve_2;Acceleration_7_mat;Acceleration_Curve_3;Acceleration_10_mat]; 

%Plots
figure(1)
plot3(Position_curve_traj(:,1),Position_curve_traj(:,2),Position_curve_traj(:,3)) %Positition Plot
figure(2)
plot(Velocity_curve_traj) %Velocity plot
figure(3)
plot(Acceleration_curve_traj) %The Acceleration plot

time=0:Ts:4;
time=transpose(time);
theta = zeros(4001,1);
theta_dot = zeros(4001,1);
theta_dotdot= zeros(4001,1);

r=zeros(599,3);
p=[Position_1_mat;Position_Curve_1;Position_4_mat;Position_Curve_2;Position_7_mat;Position_Curve_3;Position_10_mat;r]; 
rv=zeros(599,3);
pd=[Velocity_1_mat;Velocity_Curve_1;Velocity_4_mat;Velocity_Curve_2;Velocity_7_mat;Velocity_Curve_3;Velocity_10_mat;rv];
ra=zeros(599,3);
pdd=[Acceleration_1_mat;Acceleration_Curve_1;Acceleration_4_mat;Acceleration_Curve_2;Acceleration_7_mat;Acceleration_Curve_3;Acceleration_10_mat;ra];

%save for kinematic trajectory file
save('generated_kinematic_traj.mat',"p","pd","pdd","q0","time","theta","theta_dot","theta_dotdot","Ts")



